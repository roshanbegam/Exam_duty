<?php
// index.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Exam Duty Portal</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
  <style>
   :root {
  /* Updated Color Scheme from Admin Panel Screenshot */
  --sidebar-bg: #1a1f36;
  --sidebar-text: #ffffff;
  --sidebar-hover: #324060;
  --sidebar-active: #2a3349;
  --sidebar-border: #2e3a59;
  
  --content-bg: #f5f7fa;
  --card-bg: #ffffff;
  --text-primary: #333333;
  --text-secondary: #666666;
  
  --dashboard-title: #1a202c;
  --stat-card-bg: #e3f2fd;
  --stat-icon: #1976d2;
  
  --checkbox-empty: #dddddd;
  --checkbox-filled: #4CAF50;
  
  --accent-blue: #605bc2; /* Purple-blue from table header */
  --accent-blue-hover: #4a45a8;
  --success-green: #4CAF50;
  --warning-orange: #FF9800;
  --error-red: #F44336;
  --info-purple: #9C27B0;
  
  --table-header: #605bc2;
  --table-row-even: #f9fafb;
  --table-row-hover: #edf2f7;
  --table-border: #e1e1e1;
}

/* Apply the color scheme to your existing CSS */
body {
  background: var(--content-bg);
  color: var(--text-primary);
}

.header {
  background-color: var(--sidebar-bg);
  color: var(--sidebar-text);
}

.navbar button {
  background: var(--accent-blue);
  color: white;
}

.navbar button:hover {
  background: var(--accent-blue-hover);
}

.home .highlight {
  color: var(--accent-blue);
}

.home .highlight::after {
  background-color: rgba(96, 91, 194, 0.2); /* Using the table header color */
}

.btn-primary {
  background: var(--accent-blue);
}

.btn-primary:hover {
  background: var(--accent-blue-hover);
}

.feature-icon {
  background: var(--accent-blue);
}

.section-title h2::after {
  background: var(--accent-blue);
}

.marquee {
  background: var(--sidebar-bg);
}

.cta {
  background: linear-gradient(rgba(26, 31, 54, 0.8), rgba(26, 31, 54, 0.8)), url('your-image.jpg');
}

.footer {
  background: var(--sidebar-bg);
}

.social-links a:hover {
  background: var(--accent-blue);
}

.footer-links h3::after, 
.footer-contact h3::after {
  background: var(--accent-blue);
}

.footer-contact i {
  color: var(--accent-blue);
}

/* Additional elements from your screenshot */
.card {
  background: var(--card-bg);
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  padding: 20px;
  margin-bottom: 20px;
}

.menu-item {
  color: var(--sidebar-text);
}

.menu-item:hover {
  background: var(--sidebar-hover);
}

.menu-item.active {
  background: var(--sidebar-active);
  border-left: 3px solid var(--accent-blue);
}

.checkbox-item {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.checkbox-item input[type="checkbox"] {
  accent-color: var(--checkbox-filled);
}

/* Dashboard specific elements */
.dashboard-overview {
  background: var(--card-bg);
  padding: 20px;
  border-radius: 8px;
}

.stat-card {
  background: var(--stat-card-bg);
  color: var(--stat-icon);
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 15px;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .sidebar {
    width: 100%;
    position: static;
  }
  
  .main-content {
    padding: 20px 15px;
  }
}
</style>
</head>
<body>

<header class="header">
  <div class="logo"><i class="fas fa-graduation-cap"></i> Exam Duty Portal</div>
  <nav class="navbar">
    <button onclick="location.href='home.php'"><i class="fas fa-home"></i> Home</button>
    <button onclick="location.href='about.php'"><i class="fas fa-info-circle"></i> About</button>
    <button onclick="location.href='login.php'"><i class="fas fa-sign-in-alt"></i> Login</button>
    <button onclick="location.href='signup.php'"><i class="fas fa-user-plus"></i> Signup</button>
  </nav>
</header>

<section class="home">
  <div class="image animate__animated animate__fadeInLeft">
    <img src="img1.png" alt="Exam Duty">
  </div>
  <div class="content animate__animated animate__fadeInRight">
    <h3>Streamline Your <span class="highlight">Exam Duty Management</span></h3>
    <p>Comprehensive exam duty management system for invigilators and staff. Efficient scheduling, real-time updates, and seamless coordination for all your examination needs.</p>
  </div>
</section>

<section class="features">
  <div class="section-title">
    <h2>Why Choose Our Portal</h2>
  </div>
  <div class="features-container">
    <div class="feature-card animate-pop">
      <div class="feature-icon">
        <i class="fas fa-calendar-alt"></i>
      </div>
      <h3>Easy Scheduling</h3>
      <p>Automated duty scheduling with conflict detection to ensure fair distribution of exam responsibilities.</p>
    </div>
    <div class="feature-card animate-pop delay-1">
      <div class="feature-icon">
        <i class="fas fa-bell"></i>
      </div>
      <h3>Real-time Notifications</h3>
      <p>Instant alerts for duty assignments, changes, and important announcements through multiple channels.</p>
    </div>
    <div class="feature-card animate-pop delay-2">
      <div class="feature-icon">
        <i class="fas fa-chart-line"></i>
      </div>
      <h3>Performance Analytics</h3>
      <p>Track and analyze invigilator performance and attendance with comprehensive dashboards.</p>
    </div>
    <div class="feature-card animate-pop delay-3">
      <div class="feature-icon">
        <i class="fas fa-file-alt"></i>
      </div>
      <h3>Digital Reporting</h3>
      <p>Submit incident reports and exam documentation digitally with our streamlined forms.</p>
    </div>
  </div>
</section>

<div class="divider">
  <svg viewBox="0 0 1440 100" preserveAspectRatio="none">
    <path fill="#ffffff" d="M0,0 C600,100 800,0 1440,100 L1440,0 L0,0 Z"></path>
  </svg>
</div>

<div class="marquee">
  <div class="marquee-content">
    <i class="fas fa-exclamation-circle"></i> Important: All invigilators must complete the mandatory training module before accepting duties. Next training session: June 15, 2023. 
    <span style="margin: 0 50px;">|</span>
    <i class="fas fa-calendar-check"></i> Upcoming Exams: Semester Finals (June 20-30), Professional Certification (July 5), Entrance Exams (July 15-20)
    <span style="margin: 0 50px;">|</span>
    <i class="fas fa-clock"></i> Reminder: Arrive 45 minutes before exam start time for briefing and setup.
  </div>
</div>

<section class="cta">
  <h2>Ready to Transform Your Exam Management?</h2>
  <p>Join hundreds of institutions that have streamlined their examination processes with our comprehensive solution.</p>
  <div class="btn-group" style="justify-content: center;">
    <a href="signup.php" class="btn btn-primary" style="padding: 15px 30px;"><i class="fas fa-rocket"></i> Get Started</a>
    <a href="about.php" class="btn btn-success" style="padding: 15px 30px;"><i class="fas fa-play-circle"></i> Watch Demo</a>
  </div>
</section>

<footer class="footer">
  <div class="footer-container">
    <div class="footer-about">
      <div class="footer-logo">
        <i class="fas fa-graduation-cap"></i> Exam Duty Portal
      </div>
      <p>Revolutionizing exam management through technology. Our platform ensures fairness, efficiency, and transparency in examination duty allocation and coordination.</p>
      <div class="social-links">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
      </div>
    </div>
    <div class="footer-links">
      <h3>Quick Links</h3>
      <ul>
        <li><a href="home1.php"><i class="fas fa-chevron-right"></i> Home</a></li>
        <li><a href="about.php"><i class="fas fa-chevron-right"></i> About Us</a></li>
        <li><a href="features.php"><i class="fas fa-chevron-right"></i> Features</a></li>
        <li><a href="pricing.php"><i class="fas fa-chevron-right"></i> Pricing</a></li>
        <li><a href="contact.php"><i class="fas fa-chevron-right"></i> Contact</a></li>
      </ul>
    </div>
    <div class="footer-links">
      <h3>Resources</h3>
      <ul>
        <li><a href="blog.php"><i class="fas fa-chevron-right"></i> Blog</a></li>
        <li><a href="faq.php"><i class="fas fa-chevron-right"></i> FAQ</a></li>
        <li><a href="help.php"><i class="fas fa-chevron-right"></i> Help Center</a></li>
        <li><a href="webinars.php"><i class="fas fa-chevron-right"></i> Webinars</a></li>
        <li><a href="docs.php"><i class="fas fa-chevron-right"></i> Documentation</a></li>
      </ul>
    </div>
    <div class="footer-contact">
      <h3>Contact Us</h3>
      <p><i class="fas fa-map-marker-alt"></i> 123 Education Street, Academic District, New Delhi 110001</p>
      <p><i class="fas fa-envelope"></i> support@examdutyportal.com</p>
      <p><i class="fas fa-phone-alt"></i> +91 11 2345 6789</p>
      <p><i class="fas fa-clock"></i> Mon-Fri: 9AM-6PM</p>
    </div>
  </div>
  <div class="copyright">
    <p>&copy; 2023 Exam Duty Portal. All Rights Reserved. | <a href="privacy.php" style="color: var(--primary);">Privacy Policy</a> | <a href="terms.php" style="color: var(--primary);">Terms of Service</a></p>
  </div>
</footer>

<script>
  // Simple animation trigger on scroll
  document.addEventListener('DOMContentLoaded', function() {
    const animateElements = document.querySelectorAll('.animate-pop');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = 1;
          entry.target.style.transform = 'scale(1)';
        }
      });
    }, {threshold: 0.1});
    
    animateElements.forEach(el => {
      el.style.opacity = 0;
      el.style.transform = 'scale(0.8)';
      el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
      observer.observe(el);
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth'
        });
      });
    });
  });
</script>

</body>
</html>